#!/bin/bash
docker run -d --restart=always --name mggsamba  --privileged -p 139:139 -p 445:445 -v /bd_data202205/samba/etc/samba:/etc/samba -v /bd_data202205/samba/var/log/samba:/var/log/samba -v /home:/home 180.76.232.94:5000/samba:4.10.16 init
